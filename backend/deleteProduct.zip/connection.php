<?php
/*
$servername = "localhost";
$database = "seyitka1_19090700018";
$username = "seyitka1_19090700018";
$password = "beytullah123";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection*/
$servername = "127.0.0.1";
$database = "seyitka1_19090700018";
$username = "root";
$password = "1234";
$conn = mysqli_connect($servername, $username, $password, $database);
?>